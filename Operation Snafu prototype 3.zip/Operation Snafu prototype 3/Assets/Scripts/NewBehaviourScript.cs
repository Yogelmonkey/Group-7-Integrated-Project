﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{

    public float speed = -0.1f;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(x: -speed * Time.deltaTime, y: 0, z: 0);
        

        if (Input.GetKey("up"))
            transform.Translate(0f, 0f, 18 * Time.deltaTime);

        if (Input.GetKey("down"))
            transform.Translate(0f, 0f, -18 * Time.deltaTime);

        if (Input.GetKey("left"))
            transform.Translate(-18 * Time.deltaTime, 0f, 0f);

        if (Input.GetKey("right"))
            transform.Translate(18 * Time.deltaTime, 0f, 0f);
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        Destroy(gameObject);
    }
}