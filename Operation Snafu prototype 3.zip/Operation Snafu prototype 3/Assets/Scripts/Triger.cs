﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Triger : MonoBehaviour {

    public float speed = -0.1f;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter(Collider other)
    {
        transform.Translate(x: -speed * Time.deltaTime, y: 0, z: -speed);
    }

}
